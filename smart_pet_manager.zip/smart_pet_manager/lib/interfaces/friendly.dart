// Kept for clarity if you want a separate file, but we embed interface in pet.dart in this project.
// This file just re-exports a type alias to keep the folder structure clear.
typedef Friendly = Object;
